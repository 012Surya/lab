var mysql = require('mysql');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database:"mydb",
  });

  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    con.query("UPDATE customers SET name='naveen',address='e-block' WHERE name='surya'", function (err, result, fields) {
      if (err) throw err;
      console.log(result);
    });
  });